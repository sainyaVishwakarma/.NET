﻿namespace DIWebApp.Interfaces;

public interface IHelloWorldService
{
	string sayHello();
}
