﻿namespace DIWebApp.Interfaces
{
	public interface IProductCatalogService
	{
		bool Insert();
	}
}
