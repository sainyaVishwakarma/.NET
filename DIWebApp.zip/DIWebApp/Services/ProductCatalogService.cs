﻿using DIWebApp.Interfaces;

namespace DIWebApp.Services
{
	public class ProductCatalogService : IProductCatalogService
	{
		public ProductCatalogService() { }
		public bool Insert()
		{
			bool status=true;
			return status;
		}
	}
}
